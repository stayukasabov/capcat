# Research Evidence Reference

Quick reference for UX research backing Capcat design decisions. Use for portfolio presentations and stakeholder discussions.

---

## Multi-Interface Design

**Recognition vs Recall Memory**
- Recognition memory is 3x more accurate and 2x faster than recall memory.
- GUI users complete unfamiliar tasks 51% faster than CLI users.
- Working memory holds only 7±2 items, CLI commands exceed this capacity.

Sources:
- [Nielsen Norman Group - Recognition and Recall](https://www.nngroup.com/articles/recognition-and-recall/)
- Rauterberg, M. (1992). Comparing text-based and graphic user interfaces
- Sweller, J. (1988). Cognitive Load Theory

**IBM Design: Complementary Interfaces**
- "Web UIs should be complementary to CLI, not redundant."
- GUIs excel at visualization, feedback, and getting started phase.
- CLIs excel at automation, availability, and tool interoperability.
- Even die-hard CLI users are more productive with GUI in certain situations.

Sources:
- [IBM Design - Real Developers Don't Use UIs](https://medium.com/design-ibm/real-developers-dont-use-uis-daea7404fb4e)
- [Stack Exchange - CLI vs GUI Discussion](https://ux.stackexchange.com/questions/52372/why-are-graphical-user-interfaces-considered-user-friendly)

**Microsoft Inclusive Design: 808x Expansion Through Persona Spectrum**
- Designing for permanent disability (26,000 people with one arm).
- Plus temporary injury (13 million with broken arm).
- Plus situational constraint (8 million new parents holding babies).
- Total reach: 21 million people, representing 808x expansion factor.
- Applied to interfaces: some users require CLI, others need GUI, most benefit from context-based choice.
- Persona spectrum methodology helps understand mismatches across permanent, temporary, and situational scenarios.
- "Design for one, extend to many" principle: solving for specific constraints benefits broader audiences.

Sources:
- [Microsoft Inclusive Design](https://news.microsoft.com/en-xm/2019/04/26/making-the-digital-world-more-inclusive/)
- [MockFlow - Inclusive UI Design](https://mockflow.com/blog/Inclusive-UI-Design-A-Step-by-Step-Guide-to-Creating-Accessible-and-Seamless-User-Experiences)
- [CareerFoundry - Persona Spectrums](https://careerfoundry.com/en/blog/ux-design/persona-spectrums/) (May 2023)

**Google UX: Natural Surface Switching**
- Users actively switch between surfaces to decrease effort and risk.
- Switching behavior is intrinsic to completing goals faster.
- Design must enable seamless transitions across interfaces.

Sources:
- [UX Booth - User Behavior Across Surfaces](https://uxbooth.com/articles/api-cli-gui-oh-my-understanding-user-behavior-across-surfaces/)
- [IBM Design Study](https://medium.com/design-ibm/real-developers-dont-use-uis-daea7404fb4e)

---

## Progressive Disclosure and Cognitive Load

**Nielsen Norman Group: Progressive Disclosure (1995-2024)**
- Introduced by Jakob Nielsen in 1995, remains a fundamental UX pattern.
- Improves 3 of 5 usability components: learnability, efficiency, error rate.
- Show only most important options initially, reveal advanced features on request.
- Critical for terminal interfaces lacking visual hierarchy.
- Users can only hold a small amount of information in short-term memory, which fades fast.
- Helps users manage choice, feature, and function overload in complex applications.

Sources:
- [Nielsen Norman Group - Progressive Disclosure](https://www.nngroup.com/articles/progressive-disclosure/)
- [Nielsen Norman Group - Complex Application Design](https://www.nngroup.com/articles/complex-application-design/) (February 2024)
- [Nielsen Norman Group - Standards & Conventions](https://www.nngroup.com/topic/standards-conventions/)

**Cognitive Load Theory (Sweller, 1988 + Nielsen Norman Group 2024-2025)**
- Working memory capacity: 7±2 items simultaneously (Miller's Law).
- CLIs require recalling commands, flags, syntax, arguments - often exceeding working memory.
- Cognitive load is the amount of mental resources required to operate a system.
- User attention is a precious resource and should be allocated accordingly.
- Menu-based interfaces transform recall into recognition, reducing mental burden.
- Extraneous cognitive load takes up mental resources without helping users understand content.

Sources:
- [Cognitive Load in UX Design](https://gauthamprabhuk.wordpress.com/2017/06/25/cognitive-loading-in-ux-design/)
- [Nielsen Norman Group - Minimize Cognitive Load](https://www.nngroup.com/articles/minimize-cognitive-load/) (October 2024)
- [Nielsen Norman Group - Reduce Cognitive Load in Forms](https://www.nngroup.com/articles/4-principles-reduce-cognitive-load/) (July 2025)

**CLI Guidelines Project**
- "Discoverability and efficiency need not be mutually exclusive."
- Comprehensive help text with examples.
- Command suggestions and error recovery guidance.
- Steal ideas from GUIs to make CLIs learnable.

Source: [CLI Guidelines](https://clig.dev/)

**Guided Workflows**
- Give users only information they need at the moment they need it.
- Breaking processes into steps reduces decision fatigue.
- Progressive revelation as users demonstrate readiness.

Source: [Process Shepherd - Guided Workflows](https://processshepherd.com/content/guided-workflow-how-guidance-transforms-productivity/)

---

## Context Switching and Productivity

**Nielsen Norman Group: Serial Task Switching and Interruptions (2022-2025)**
- Serial task switching means rapidly shifting between tasks, not true multitasking.
- Constant interruptions prevent entering flow state where deep work happens.
- People who switch between many tasks take longer to finish and produce lower-quality work.
- Frequent resetting strains cognitive resources and causes stress.
- Users interrupted during workflows may not remember what information they were seeking or which steps they completed.
- Complex work requires users to hold substantial information in working memory, which is easily lost during interruptions.
- Unexpected and jarring interruptions in work translate to lost productivity and increased error rates.

Sources:
- [Nielsen Norman Group - Serial Task Switching](https://www.nngroup.com/articles/serial-task-switching/) (May 2025)
- [Nielsen Norman Group - Designing for Long Waits and Interruptions](https://www.nngroup.com/articles/designing-for-waits-and-interruptions/) (July 2022)
- [Nielsen Norman Group - Complex Application Design](https://www.nngroup.com/articles/complex-application-design/) (February 2024)

**Multitasking Productivity Loss: 40% Reduction**
- Task switching can reduce productivity by up to 40%.
- Only 2.5% of people can effectively multitask.
- Multitasking increases error rates by 12.6%.
- Heavy multitasking can drop IQ by up to 10 points temporarily.

Sources:
- [PMC - Digital Multitasking Study 2024](https://pmc.ncbi.nlm.nih.gov/articles/PMC11543232/)
- [ActivTrak - Multitasking Impact Research](https://www.activtrak.com/blog/how-is-productivity-affected-when-employees-multitask/)
- [Psychology Today via Sarah Merron](https://sarahmerron.com/multitasking-makes-you-40-less-productive/)

**Context Switching Costs and Recovery Time**
- Developers switch tasks 13 times per hour.
- Recovery time: 10-15 minutes minimum, 20-30 minutes for complex tasks.
- 31.6 interruptions per day on average.
- Takes 23 minutes on average to refocus after switching.
- 20% of cognitive capacity lost when context switch occurs.

Sources:
- [ContextKeeper - Interruption Study](https://contextkeeper.io/blog/the-real-cost-of-an-interruption-and-context-switching/)
- [Monitask - Task Switching Cost](https://www.monitask.com/en/business-glossary/task-switching-cost)
- [Reclaim AI - Context Switching Research](https://reclaim.ai/blog/context-switching)

**Financial Impact of Context Switching**
- Annual cost: $450 billion in US alone.
- Average office worker switches tasks 300+ times per day.
- Developers lose up to 20% of productive time due to task switching.
- Workplace Research Foundation: global economy impact measured in hundreds of billions.

Sources:
- [Monitask - Economic Impact](https://www.monitask.com/en/business-glossary/task-switching-cost)
- [Pieces App - Context Switching Costs](https://pieces.app/blog/cost-of-context-switching)
- [Journal of Systems and Software Research](https://contextkeeper.io/blog/the-real-cost-of-an-interruption-and-context-switching/)

**Remote Work and Tool Fragmentation**
- 76% of remote workers report more context switching than in-office work (Slack 2023).
- Employees lose 3.6 hours per week switching between 10+ apps.
- 77% of employees saved up to 3.6 hours weekly through automation (2023).
- Integrated environments dramatically improve efficiency.

Sources:
- [Pieces App - Remote Work Context Switching](https://pieces.app/blog/cost-of-context-switching)
- [Productivity Statistics 2024](https://electroiq.com/stats/productivity-in-the-workplace-statistics/)
- [Formstack - Automation Statistics](https://www.formstack.com/blog/workflow-automation-statistics)

**Workflow Automation Benefits**
- 60% of employees could save 30% of their time with automation (McKinsey).
- Automation eliminates repetitive manual processes.
- Tool consolidation reduces app-switching friction.
- By 2030, workplaces managing task switching effectively could see 25% productivity increases.

Sources:
- [Formstack - Workflow Automation](https://www.formstack.com/blog/workflow-automation-statistics)
- [McKinsey via Monitask](https://www.monitask.com/en/business-glossary/task-switching-cost)
- [Productivity Statistics](https://electroiq.com/stats/productivity-in-the-workplace-statistics/)

---

## Link Rot and Digital Preservation

**Pew Research Center (2024): Web Content Decay**
- 38% of webpages from 2013 are completely inaccessible by 2024.
- 23% of news webpages contain at least one broken link.
- 54% of Wikipedia pages have at least one broken reference.
- 21% of government webpages contain broken links.
- 8% decay rate for pages just 2 years old (2021 to 2023).

Sources:
- [Pew Research - Link Rot Study](https://www.pewresearch.org/data-labs/2024/05/17/when-online-content-disappears/)
- [Search Engine Journal Coverage](https://www.searchenginejournal.com/38-of-webpages-from-2013-have-vanished-pew-study-finds/516834/)

**Ahrefs Link Rot Study (2022)**
- 66.5% of links have rotted since 2013.
- 1.3% of links die per week in continuous crawls.
- After 1 year: 17.37% of links rot.
- After 3 years: 28.4% of links rot.
- After 7 years: 43.39% of links rot.

Sources:
- [Ahrefs Link Rot Study](https://ahrefs.com/blog/link-rot-study/)
- [Linkody Research](https://blog.linkody.com/case-studies/link-rot)
- [InfoDocket Coverage](https://www.infodocket.com/2021/05/21/link-rot-research-what-the-ephemerality-of-the-web-means-for-your-hyperlinks/)

**Columbia Journalism Review: NYT Analysis**
- 25% of all deep links are completely inaccessible.
- 53% of NYT articles with deep links have at least one rotted link.
- 72% of links from 1998 have rotted versus 6% from 2018.
- 13% of "working" links have drifted significantly from original content.

Sources:
- [CJR - Link Rot Analysis](https://www.cjr.org/analysis/linkrot-content-drift-new-york-times.php)
- [Loganix - Link Rot Impact](https://loganix.com/what-is-link-rot/)

**Local-First Software Manifesto (Ink & Switch, 2019)**
- Seven ideals: fast, multi-device, offline, collaborative, durable, secure, user-owned.
- Primary data lives on user device, servers hold secondary copies.
- Applications continue working even if service shuts down.
- CRDTs enable automatic merging without central coordination.

Sources:
- [Ink & Switch - Local-First Software](https://www.inkandswitch.com/essay/local-first/)
- [PowerSync - Local-First Origins](https://www.powersync.com/blog/local-first-software-origins-and-evolution)

**Offline-First Design Patterns (A List Apart)**
- Email inbox/outbox model is UX gold standard.
- Stop treating lack of connectivity like an error.
- Apps should handle disconnections gracefully.
- Downloaded content remains accessible offline.

Sources:
- [A List Apart - Offline First](https://alistapart.com/article/offline-first/)
- [Creative Bloq - Design for Offline](https://www.creativebloq.com/features/design-for-offline)

---

## Nielsen's Usability Heuristics for CLI/TUI

**10 Usability Heuristics (Nielsen, 1990)**
- Originally tested on terminal-based program.
- Grounded in fundamental human-machine mismatches.
- Unchanged for 30+ years because they transcend specific technologies.

Source: [Nielsen Norman Group - 10 Heuristics](https://www.nngroup.com/articles/ten-usability-heuristics/)

**Heuristic 6: Recognition Rather Than Recall**
- Command line interfaces are based on recall.
- Modern solutions: tab completion, help text, command history, suggestions.
- Transform recall burden into recognition task.

**Heuristic 3: User Control and Freedom**
- Ctrl-C should exit as soon as possible (CLI Guidelines).
- Dry-run options preview operations before execution.
- Confirmation dialogs protect against dangerous actions.

**Heuristic 7: Flexibility and Efficiency**
- Shortcuts for experts: aliases, keyboard shortcuts, short flags.
- Both -h and --help for different user preferences.
- Machine-readable output (--json) for piping to other tools.

**Heuristic 1: Visibility of System Status**
- Progress indicators and spinners critical for text interfaces.
- Atlassian: particularly relevant for CLI-only interfaces.
- Real-time feedback during long operations.

Source: [Atlassian - CLI Design Principles](https://blog.developer.atlassian.com/10-design-principles-for-delightful-clis/)

---

## Accessibility and Cognitive Diversity

**W3C Cognitive Accessibility**
- WCAG 1.3: Create content presentable in different ways.
- Technology provides opportunities to navigate using different strategies.
- Users must be able to change presentation according to needs.

Source: [W3C Cognitive Accessibility](https://www.w3.org/WAI/cognitive/)

**Neurodiversity Statistics and Interface Needs (2024-2025)**
- 15-20% of population is neurodivergent (approximately one in every eight people worldwide).
- Each has unique interface needs: visual clutter sensitivity, predictable navigation, customizable colors.
- Interface accessibility means devices can be modified with minimal difficulty to suit individual needs.
- Different cognitive styles require different interaction approaches: visual thinking, pattern recognition, etc.
- Flexibility in UI design allows users to choose best interaction mode for their cognitive profile.

Sources:
- [Aspiritech - Neurodiversity and Accessibility](https://aspiritech.org/featured/why-accessibility-isnt-complete-without-considering-neurodiversity/)
- [UXpa Magazine - Neurodiversity Inclusive UX](https://uxpamagazine.org/neurodiversity-inclusive-user-experience/) (December 2024)
- [Springer - Designing for Neurodiverse Users](https://academic.oup.com/iwc/advance-article/doi/10.1093/iwc/iwaf037/8276143) (October 2025)

**Multimodal Interaction Research**
- Users' multimodal interaction increases from 18.6% to 77.1% in new contexts.
- Increases from 59.2% to 75.0% on high-difficulty tasks.
- Different users find different interfaces accessible based on context.

Source: [ScienceDirect - Multimodal Interface](https://www.sciencedirect.com/topics/computer-science/multimodal-interface)

**ACM CHI: CLI Accessibility Study (2021)**
- CLIs have accessibility issues as "unstructured text interfaces."
- Blind developers frequently use CLIs and find them more accessible than visual IDEs.
- Different users find different interfaces accessible based on specific needs.

Source: [ACM Digital Library - CLI Accessibility](https://dl.acm.org/doi/fullHtml/10.1145/3411764.3445544)

---

## Industry Validation and Adoption

**Git and GitKraken**
- GitHub: 100 million developers globally.
- GitKraken: 40 million developers, $10.6M annual revenue.
- Repository operations 5x faster in GUI.
- CLI remains standard for automation and scripting.

Sources:
- [GitHub Statistics](https://coinlaw.io/statistics/github-statistics/)
- [GitKraken Revenue](https://getlatka.com/companies/gitkraken.com)

**Docker Desktop**
- 2.4M to 2.9M installations in 8 months (Nov 2019 - July 2020).
- 242 billion total pulls, 11 billion pulls per month.
- 7 million Docker Hub users.
- 78% developer satisfaction (Stack Overflow 2024).

Source: [Docker Growth Statistics](https://www.docker.com/blog/docker-index-dramatic-growth-in-docker-usage-affirms-the-continued-rising-power-of-developers/)

**AWS Dual Interface**
- Management Console for beginners and visualization.
- CLI for automation and bulk operations.
- Creating 10 EC2 instances: 30-60 minutes via Console, 30 seconds via CLI.
- 60-120x speed improvement for appropriate use cases.

Source: [AWS Interface Guide](https://trailhead.salesforce.com/content/learn/modules/aws-cloud-technical-professionals/navigate-the-aws-management-interfaces)

**Visual Studio Code**
- 2.6M users (2017) to 50M monthly active (2025).
- 74%+ IDE market share (Stack Overflow).
- 28,000+ extensions from 20,000 authors.
- Balance between full IDE and simple editor with integrated terminal.

Source: [VS Code Adoption](https://www.techtarget.com/searchsoftwarequality/news/252496429/Microsoft-VS-Code-Winning-developer-mindshare)

**GitHub Copilot**
- 81.4% of developers installed extension on day one.
- 67% using it at least 5 days per week.
- Time to PR reduced 75%: 9.6 days to 2.4 days.
- Code quality maintained despite increased speed.

Source: [GitHub Copilot Adoption](https://opsera.ai/blog/github-copilot-adoption-trends-insights-from-real-data/)

---

## Power User vs Novice Research

**Nielsen Norman Group: Expert vs Novice Users**
- Telephone company case study: optimizing commands saved $10 million annually.
- Experts prioritize speed and efficiency over learnability.
- Novices focus on perceptually salient surface features.
- Experts integrate structural, functional, behavioral elements.

Source: [Nielsen Norman Group - Novice vs Expert](https://www.nngroup.com/articles/novice-vs-expert-users/)

**Cognitive Differences Research**
- Novices cite usability requirements 39.4% vs experts 17.1%.
- Experts cite functionality requirements 35.4% vs novices 16.7%.
- Complete inversion of priorities between skill levels.
- Experts "chunk" information, freeing mental resources.

**Multi-Layer Interface Design**
- Limited feature set on Layer 1 for beginners.
- Progressive disclosure of advanced features for experts.
- Experts not distracted by novice features if shortcuts bypass them.
- PowerShell: console-based UI great for experts, not for beginners.

Source: [Multi-Layer Interface Research](https://link.springer.com/chapter/10.1007/978-3-642-21660-2_18)

---

## Shell Aliases and Workflow Optimization

**Developer Productivity with Aliases**
- Transform long commands into short, memorable shortcuts.
- Reduce typing errors and cognitive load.
- Personalize workflow to individual preferences.
- Industry standard practice among CLI power users.

Sources:
- [Dev.to - Workflow Aliases](https://dev.to/ernestohs/empower-your-workflow-with-aliases-save-time-by-being-lazy-4m6o)
- [Medium - Git Bash Aliases](https://awesomebobx64.medium.com/git-bash-aliases-to-speed-up-your-day-baceb6a74ba9)

---

## Command-Line Anxiety Research

**Four Primary Anxiety Sources**
- Fear of irreversible damage.
- Memorization burden for commands and syntax.
- Poor early experiences (DOS-era trauma).
- Perception as expert-only tools.

Source: [Overcoming CLI Fear](https://zellwk.com/blog/fear-of-command-line/)

**Barrier Reduction Techniques**
- Tab completion transforms recall into recognition.
- Interactive prompts guide through complex operations.
- Dry-run modes allow preview before committing.
- Showing CLI equivalents alongside GUI actions enables organic learning.

---

## Quick Reference Summary

| Design Decision | Research Backing | Key Metric |
|----------------|------------------|------------|
| Dual interface (TUI + CLI) | IBM, Microsoft, Nielsen | 808x user reach expansion |
| Progressive disclosure | Nielsen Norman Group | 3x memory accuracy improvement |
| CLI automation | McKinsey, AWS | 30-75% time savings |
| Local-first architecture | Pew, Ink & Switch | 38% web decay in 10 years |
| Comment preservation | Multiple sources | Complete context for ML datasets |
| Recognition over recall | Nielsen Norman Group | 51% faster for unfamiliar tasks |
| Context switching reduction | ContextKeeper | $450B annual productivity cost |

---

Use this reference when presenting Capcat to hiring managers, stakeholders, or product teams. Each design choice traces to specific, quantified research findings.
