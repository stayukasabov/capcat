# User Journey: ML Engineer Data Pipeline

## Journey Overview

**Persona**: ML/AI Engineer (Dr. Jordan Park)
**Duration**: 1 hour weekly curation, 24/7 automated collection
**Interface**: Hybrid (TUI for exploration, CLI for production)
**Time saved**: 90% vs manual dataset curation

## Emotional Arc

```
5 (Breakthrough)           ●
4 (Confident)         ●━━━━●
3 (Optimizing)      ●
2 (Building)       ●
1 (Exploring)     ●
                  │ │ │ │ │
                  TUI Test
                  Pipeline Build
                  Automation
                  RAG Deploy
                  Production Scale
```

## Journey Flow Diagram

```mermaid
graph TD
    A[Week 1: Exploration] --> B[Test Data Quality]
    B --> C[./capcat catch]
    C --> D[Add Source → Test RSS]

    D --> E{Quality Check}
    E -->|Good| F[Add to Production Sources]
    E -->|Poor| G[Try Different Source]

    F --> H[Week 2: Pipeline Development]
    G --> D

    H --> I[Write Metadata Extractor]
    I --> J[metadata-extract.py]
    J --> K[Test with Sample Articles]

    K --> L[Week 3: CLI Automation]
    L --> M[Bulk Collection Script]
    M --> N[./capcat bundle ai,techpro,science --count 500]

    N --> O[Convert to Training Format]
    O --> P[JSONL for LLM fine-tuning]

    P --> Q[Week 4: RAG Integration]
    Q --> R[Generate Embeddings]
    R --> S[ChromaDB Vector Storage]

    S --> T[Month 2: Production Deployment]
    T --> U[Cron: Daily Collection]
    U --> V[Automated Pipeline]
    V --> W[3,000+ Articles/Month]

    W --> X[Month 3: Advanced Use Cases]
    X --> Y[LLM Fine-tuning Dataset]
    X --> Z[RAG Knowledge Base]
    X --> AA[Sentiment Analysis Corpus]

    Y --> AB[Production AI Model]
    Z --> AC[Semantic Search System]
    AA --> AD[Trend Dashboard]

    style F fill:#d4f1d4
    style V fill:#e1f5e1
    style AB fill:#d4f1d4
    style AC fill:#d4f1d4
```

## Detailed Timeline

### Week 1: Source Quality Validation (3 hours)

**Friday 2:00 PM**: Interactive source testing

**TUI Workflow**:
```
./capcat catch

? What would you like to do?
  ❯ Manage Sources

? Source Management:
  ❯ Add New Source
    Remove Source
    List All Sources
    Test Source

? Enter RSS feed URL:
> https://blog.research-lab.com/rss

Introspecting feed...
✓ Found: AI Research Lab Blog
✓ 25 recent articles
✓ Full-text content available

? Generate config for this source? Yes

Generated: sources/active/config_driven/configs/research-lab.yaml

? Test source with 5 articles? Yes

Fetching 5 test articles...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 5/5

✓ Test complete: ../News/test_research-lab/
```

**Quality Validation**:
```bash
cd ../News/test_research-lab/
cat 01_*/article.md

# Check for:
# - Clean Markdown ✓
# - Code blocks preserved ✓
# - Math equations intact ✓
# - Images downloaded ✓
# - Metadata complete ✓
```

**Decision**: Add to production sources
**Emotion**: Satisfied, data quality confirmed

---

### Week 2: Pipeline Development (8 hours)

**Metadata Extraction Script**:
```python
# metadata-extract.py

import frontmatter
from pathlib import Path
import json

def extract_metadata(article_path):
    """Extract structured metadata from Capcat articles"""

    with open(article_path) as f:
        post = frontmatter.load(f)

    metadata = {
        "title": post.get("title", ""),
        "url": post.get("url", ""),
        "source": post.get("source", ""),
        "published": post.get("published", ""),
        "author": post.get("author", ""),
        "content": post.content,
        "word_count": len(post.content.split()),
        "has_code": "```" in post.content,
        "has_images": "![" in post.content
    }

    return metadata

def process_news_directory(news_dir):
    """Process all articles in Capcat news directory"""

    articles = []

    for article_file in Path(news_dir).rglob("article.md"):
        try:
            metadata = extract_metadata(article_file)
            articles.append(metadata)
        except Exception as e:
            print(f"Error processing {article_file}: {e}")

    return articles

# Usage
articles = process_news_directory("../News/news_18-11-2025/")
print(f"Processed {len(articles)} articles")
```

**Test Run**:
```bash
python3 metadata-extract.py
# Processed 500 articles
# Average word count: 1,247
# Code blocks: 73%
# Images: 89%
```

**Emotion**: Engaged, building data infrastructure

---

### Week 3: Bulk Collection Automation (4 hours)

**Collection Script** (collect-training-data.sh):
```bash
#!/bin/bash

# Configuration
CAPCAT_PATH="/Users/jordan/capcat/Application/capcat"
NEWS_DIR="/Users/jordan/News"
DATASETS_DIR="/Users/jordan/ml-datasets"
LOG_FILE="/Users/jordan/logs/data-collection.log"

echo "[$(date)] Starting data collection..." >> "$LOG_FILE"

# Bulk fetch: 500 articles from AI/tech sources
$CAPCAT_PATH bundle ai,techpro,science --count 500 >> "$LOG_FILE" 2>&1

if [ $? -eq 0 ]; then
    echo "[$(date)] Fetch successful" >> "$LOG_FILE"

    # Extract metadata
    python3 /Users/jordan/scripts/metadata-extract.py \
        --input "$NEWS_DIR/news_$(date +%d-%m-%Y)/" \
        --output "$DATASETS_DIR/metadata_$(date +%Y%m%d).json"

    # Convert to JSONL for training
    python3 /Users/jordan/scripts/convert-to-jsonl.py \
        --input "$DATASETS_DIR/metadata_$(date +%Y%m%d).json" \
        --output "$DATASETS_DIR/training_$(date +%Y%m%d).jsonl"

    echo "[$(date)] Pipeline complete" >> "$LOG_FILE"
else
    echo "[$(date)] Fetch failed" >> "$LOG_FILE"
    exit 1
fi
```

**First Run**:
```bash
chmod +x collect-training-data.sh
./collect-training-data.sh

# Output:
# Fetching 500 articles...
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 500/500
# Metadata extracted: 487/500 (97% success)
# JSONL created: 487 records, 612 MB
```

**Emotion**: Confident, pipeline operational

---

### Week 4: RAG Integration (10 hours)

**Embedding Generation**:
```python
# generate-embeddings.py

from sentence_transformers import SentenceTransformer
import chromadb
from pathlib import Path
import json

def build_rag_kb(news_dir, collection_name="tech_articles"):
    """Build RAG knowledge base from Capcat articles"""

    # Initialize embedding model
    model = SentenceTransformer('all-MiniLM-L6-v2')

    # ChromaDB setup
    client = chromadb.PersistentClient(path="./chroma_db")
    collection = client.create_collection(collection_name)

    articles_processed = 0

    for article_file in Path(news_dir).rglob("article.md"):
        with open(article_file) as f:
            content = f.read()

        # Generate embedding
        embedding = model.encode(content)

        # Add to vector DB
        collection.add(
            documents=[content],
            embeddings=[embedding.tolist()],
            metadatas=[{
                "path": str(article_file),
                "source": article_file.parent.parent.name
            }],
            ids=[str(article_file.parent)]
        )

        articles_processed += 1
        if articles_processed % 50 == 0:
            print(f"Processed {articles_processed} articles...")

    print(f"✓ RAG KB built: {articles_processed} articles")
    return collection

# Build knowledge base
kb = build_rag_kb("../News/news_18-11-2025/")
```

**Query Interface**:
```python
# query-rag.py

def query_knowledge_base(query, top_k=5):
    """Semantic search over tech articles"""

    model = SentenceTransformer('all-MiniLM-L6-v2')
    client = chromadb.PersistentClient(path="./chroma_db")
    collection = client.get_collection("tech_articles")

    query_embedding = model.encode(query)

    results = collection.query(
        query_embeddings=[query_embedding.tolist()],
        n_results=top_k
    )

    return results

# Test query
results = query_knowledge_base(
    "What are recent LLM breakthroughs?",
    top_k=5
)

for doc in results['documents'][0]:
    print(f"\n{doc[:200]}...")
```

**Test Results**:
```
Query: "What are recent LLM breakthroughs?"

✓ Retrieved 5 relevant articles:
  1. GPT-4 Turbo with 128K context (0.92 relevance)
  2. Anthropic Claude 2.1 improvements (0.89 relevance)
  3. Google Gemini multimodal capabilities (0.87 relevance)
  4. Meta Llama 2 open-source release (0.84 relevance)
  5. Mistral AI 7B performance (0.81 relevance)
```

**Emotion**: Breakthrough, RAG system working

---

### Month 2: Production Deployment (3 hours setup)

**Cron Automation**:
```bash
crontab -e

# Daily data collection at 2 AM
0 2 * * * /Users/jordan/scripts/collect-training-data.sh

# Weekly embedding update (Sunday 3 AM)
0 3 * * 0 /Users/jordan/scripts/update-embeddings.sh

# Monthly backup (1st of month, 4 AM)
0 4 1 * * /Users/jordan/scripts/backup-datasets.sh
```

**Monitoring Script** (update-embeddings.sh):
```bash
#!/bin/bash

echo "[$(date)] Updating RAG embeddings..." >> /Users/jordan/logs/embeddings.log

python3 /Users/jordan/scripts/generate-embeddings.py \
    --input /Users/jordan/News/news_$(date +%d-%m-%Y)/ \
    --incremental \
    >> /Users/jordan/logs/embeddings.log 2>&1

echo "[$(date)] Embeddings updated" >> /Users/jordan/logs/embeddings.log
```

**Production Metrics**:
```bash
# After 1 month of automation
Total articles collected: 3,247
Dataset size: 4.1 GB
Embedding vectors: 3,247
RAG queries/day: 150
Retrieval accuracy: 92%
```

**Emotion**: Empowered, production system scaled

---

### Month 3: Advanced Use Cases

**Use Case 1: LLM Fine-Tuning**
```python
# finetune-tech-llm.py

from datasets import load_dataset
import openai

# Load Capcat-curated dataset
dataset = load_dataset(
    "json",
    data_files="datasets/training_*.jsonl"
)

# Fine-tune GPT-3.5
openai.FineTune.create(
    training_file="training_202411.jsonl",
    model="gpt-3.5-turbo",
    suffix="tech-expert"
)

# Result: gpt-3.5-turbo:ft-tech-expert-2024-11
```

**Use Case 2: Sentiment/Topic Tracking**
```python
# analyze-trends.py

from transformers import pipeline

sentiment_model = pipeline("sentiment-analysis")
topic_model = pipeline(
    "zero-shot-classification",
    model="facebook/bart-large-mnli"
)

def analyze_monthly_trends(articles):
    """Track AI/ML topic trends over time"""

    topics = ["LLM", "Computer Vision", "Robotics", "Ethics"]
    monthly_trends = {}

    for article in articles:
        # Topic classification
        result = topic_model(
            article['content'][:512],
            candidate_labels=topics
        )

        top_topic = result['labels'][0]
        monthly_trends[top_topic] = monthly_trends.get(top_topic, 0) + 1

    return monthly_trends

# Output: {"LLM": 142, "Computer Vision": 89, "Ethics": 67, "Robotics": 45}
```

**Use Case 3: Comment Analysis**
```python
# analyze-comments.py

def extract_technical_discussions(news_dir):
    """Build conversational dataset from HN/Lobsters"""

    threads = []

    for comments_file in Path(news_dir).rglob("comments.md"):
        with open(comments_file) as f:
            content = f.read()

        # Parse nested comments
        thread = parse_comment_thread(content)

        # Filter high-quality technical discussions
        if thread['depth'] >= 3 and thread['avg_length'] > 100:
            threads.append(thread)

    return threads

# Result: 847 technical discussion threads
# Avg depth: 4.2 levels
# Avg length: 156 words/comment
```

---

## Automation Architecture

```mermaid
graph TB
    A[2 AM Daily Cron] --> B[Bulk Capcat Fetch]
    B --> C[500 Articles]

    C --> D[Metadata Extract]
    D --> E[JSONL Conversion]

    E --> F{Use Case Router}

    F --> G[LLM Fine-tuning]
    F --> H[RAG Embedding]
    F --> I[Sentiment Analysis]

    G --> J[Training Dataset]
    H --> K[Vector DB]
    I --> L[Trend Dashboard]

    K --> M[3 AM Weekly: Update Embeddings]
    M --> N[Incremental Sync]

    J --> O[Monthly: Model Training]
    L --> P[Daily: Dashboard Update]
```

## Before/After Comparison

### Before Capcat (10 hours weekly)

| Task | Time | Tool | Friction |
|------|------|------|----------|
| Find technical articles | 180 min | Google Scholar, arXiv | High |
| Manual download | 120 min | Browser | Very high |
| Format conversion | 90 min | Pandoc, manual | High |
| Metadata extraction | 60 min | Manual | Very high |
| Quality filtering | 60 min | Manual review | High |
| Organize dataset | 30 min | File system | Medium |
| **Total** | **600 min** | **Multiple** | **Exhausting** |

### With Capcat (1 hour weekly)

| Task | Time | Tool | Friction |
|------|------|------|----------|
| Source quality testing (TUI) | 30 min | Capcat catch | Low |
| Pipeline monitoring | 20 min | Log review | Low |
| Dataset validation | 10 min | Python scripts | Low |
| Automated collection | 0 min | Cron (automated) | None |
| Metadata extraction | 0 min | Automated | None |
| Format conversion | 0 min | Automated | None |
| **Total** | **60 min** | **Integrated** | **Minimal** |

**Time saved**: 540 minutes weekly (90%)

---

## Success Metrics

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Weekly curation time | 600 min | 60 min | -90% |
| Articles collected/month | 300 | 3,000 | +900% |
| Data quality | 70% | 98% | +28% |
| RAG retrieval accuracy | N/A | 92% | New capability |
| LLM training dataset | 500 articles | 10,000+ articles | +1,900% |
| Manual intervention | 100% | 5% | -95% |

---

## Hybrid Interface Strategy

**TUI Usage (10% of time)**:
- Source quality validation
- New RSS feed testing
- Quick single-article captures
- Visual output verification

**CLI Usage (90% of time)**:
- Production bulk collection
- Pipeline automation
- Dataset generation
- Integration scripting

**Why Hybrid Works**:
- TUI: Exploration without syntax errors
- CLI: Production automation at scale
- Context-driven interface selection
- Best of both worlds

---

## Pain Points Solved

| Original Pain | Capcat Solution | Impact |
|---------------|-----------------|--------|
| Manual curation (10 hrs) | Automated pipeline | 90% time savings |
| Inconsistent formats | Standardized Markdown | 98% data quality |
| Small datasets | 3,000+ articles/month | 10x dataset size |
| No metadata | Preserved frontmatter | Pipeline-ready |
| Manual quality filtering | RSS introspection | Automated validation |

---

## User Quote

> "TUI for source testing, CLI for production. 3,000+ curated articles monthly fuel LLM fine-tuning and RAG. Automated pipeline reduced 10-hour weekly curation to 1-hour supervision. RAG retrieval accuracy: 92%."
>
> — Dr. Jordan Park, ML Engineer

---

## Future Optimization

**Current**: Manual source quality testing (30 min weekly)

**Potential**: Automated quality scoring
```python
# auto-quality-score.py

def score_source_quality(test_articles):
    """Automatically score RSS source for ML use"""

    scores = {
        "markdown_cleanliness": analyze_markdown(test_articles),
        "code_preservation": check_code_blocks(test_articles),
        "metadata_completeness": validate_metadata(test_articles),
        "content_depth": measure_word_count(test_articles)
    }

    total_score = sum(scores.values()) / len(scores)

    return total_score >= 0.85  # Auto-add if score > 85%
```

**Result**: Full automation, zero manual curation
