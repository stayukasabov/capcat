# User Journey: Product Designer Workflow

## Journey Overview

**Persona**: Product Designer (Maya Chen)
**Duration**: 30 minutes, 3x weekly
**Interface**: Interactive TUI menu (primary)
**Time saved**: 67% vs manual collection

---


## Emotional Arc

```
5 (Confident)     ●━━━━━●
4 (Satisfied)    ●       ●
3 (Engaged)     ●
2 (Curious)   ●
1 (Anxious)  ●
             │ │ │ │ │ │
             Launch Menu
             Visual Selection
             Progress Watch
             HTML Preview
             Import to Figma
             Team Share
```

## Journey Flow Diagram

```mermaid
graph TD
    A[Monday 9:00 AM] --> B[Open Terminal]
    B --> C[./capcat catch]
    C --> D[ASCII Logo Displays]

    D --> E[Main Menu]
    E --> F[Select: Catch from Bundle]

    F --> G[Bundle Selection Screen]
    G --> H{Choose Bundle}
    H -->|tech| I[tech: gizmodo + futurism + ieee]
    H -->|techpro| J[techpro: hn + lb + iq]

    I --> K[Set Article Count]
    K --> L[Enter: 15]

    L --> M[Enable HTML Generation?]
    M --> N[Select: Yes]

    N --> O[Confirm Settings]
    O --> P{Preview}
    P -->|Looks Good| Q[Execute]
    P -->|Change| K

    Q --> R[Parallel Fetching]
    R --> S[Visual Progress Bars]
    S --> T[gizmodo: ━━━━━━━━━ 5/5]
    S --> U[futurism: ━━━━━━━━━ 5/5]
    S --> V[ieee: ━━━━━━━━━━━━ 5/5]

    T --> W[Combine Results]
    U --> W
    V --> W

    W --> X[Generate HTML Report]
    X --> Y[✓ 15 articles saved]

    Y --> Z[Navigate to Output]
    Z --> AA[Open HTML in Browser]
    AA --> AB[Review Visual Content]

    AB --> AC[Select 8 Relevant Articles]
    AC --> AD[Open Figma]
    AD --> AE[Import Images to Mood Board]

    AE --> AF[Share HTML with Team]
    AF --> AG[Done: 9:30 AM]

    style D fill:#e1f5e1
    style S fill:#e1f5e1
    style Y fill:#d4f1d4
    style AG fill:#d4f1d4
```

## Detailed Timeline

### 9:00-9:05 AM: Launch and Configure

**Action**: Start interactive menu

**Terminal Output**:
```
./capcat catch

   ____
 / ____|                     _
| |     __ _ _ __   ___ __ _| |_
| |    / _  |  _ \ / __/ _  | __|
| |___| (_| | |_) | (_| (_| | |_
 \_____\__,_|  __/ \___\__,_|\__|
            | |
            |_|

? What would you like to do?
  ❯ Catch from Bundle
    Catch from Multiple Sources
    Catch from Single Source
    Catch Single URL
    Manage Sources
    Exit
```

**Selections**:
```
? Select bundle:
  ❯ tech (gizmodo + futurism + ieee)
    techpro (hn + lb + iq)
    news (bbc + guardian)

? How many articles per source? 5

? Generate HTML report? Yes
```

**Emotion**: Confident, familiar with interface
**Friction**: Zero (visual guidance)

---

### 9:05-9:10 AM: Automated Fetching

**Action**: Watch progress bars

**Output**:
```
Fetching tech bundle (3 sources, 15 articles total)...

Gizmodo:         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 5/5
Futurism:        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 5/5
IEEE Spectrum:   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 5/5

Generating HTML report...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100%

✓ 15 articles saved to ../News/news_18-11-2025/
✓ HTML report: ../News/news_18-11-2025/html/index.html
```

**Emotion**: Satisfied, visual feedback reassuring
**Duration**: 4 minutes

---

### 9:10-9:20 AM: Review HTML Report

**Action**: Browse visual content

**Browser Navigation**:
```
../News/news_18-11-2025/html/index.html

┌─────────────────────────────────────────┐
│  Tech Bundle - November 18, 2025        │
│  15 Articles | 3 Sources               │
├─────────────────────────────────────────┤
│                                         │
│  [Image] AI Design Tools Revolution     │
│  Gizmodo | 5 min read                   │
│  ⭐ Relevant for mood board             │
│                                         │
│  [Image] Figma Plugin Ecosystem 2025    │
│  Futurism | 8 min read                  │
│  ⭐ Relevant for design systems         │
│                                         │
│  [Image] Typography Trends in AI Apps   │
│  IEEE | 12 min read                     │
│  ⭐ Relevant for type guidelines        │
│                                         │
└─────────────────────────────────────────┘
```

**Selection Process**:
- Scan images (2 min)
- Read headlines (3 min)
- Tag 8 relevant articles (5 min)

**Emotion**: Engaged, curatorial mode

---

### 9:20-9:25 AM: Import to Design Tools

**Action**: Extract visual inspiration

**Figma Workflow**:
```
1. Open Figma → Design Inspiration Board
2. Create frame: "Nov 18 - AI Design Trends"
3. Import images from HTML report:
   - Right-click images → Save
   - Drag into Figma frame
4. Add annotations:
   - Source attribution
   - Relevance notes
   - Application ideas
```

**Images Imported**: 12 from 8 articles
**Emotion**: Creative, inspired

---

### 9:25-9:30 AM: Team Sharing

**Action**: Distribute HTML report

**Slack Message**:
```
#design-team

Hey team! This week's tech design inspiration:
🔗 /SharePoint/Design-Inspiration/news_18-11-2025/html/

Highlights:
• AI design tools getting seriously good
• Figma plugin ecosystem exploding
• Typography trends for AI interfaces

Check it out before Friday's review!
```

**Emotion**: Accomplished, collaborative

---

## Before/After Comparison

### Before Capcat (90 minutes)

| Task | Time | Tool | Friction |
|------|------|------|----------|
| Browse 10+ sites | 30 min | Browser | High |
| Screenshot articles | 20 min | Manual | Very high |
| Save images individually | 15 min | Right-click save | High |
| Organize in folders | 10 min | Finder | Medium |
| Import to Figma | 10 min | Drag-drop | Medium |
| Share with team | 5 min | Slack/email | Low |
| **Total** | **90 min** | **Multiple** | **Exhausting** |
### With Capcat (30 minutes)

| Task | Time | Tool | Friction |
|------|------|------|----------|
| Launch menu | 2 min | Capcat TUI | None |
| Configure fetch | 3 min | Visual selection | None |
| Automated collection | 4 min | Capcat (automated) | None |
| Review HTML | 10 min | Browser | Low |
| Import to Figma | 8 min | Batch import | Low |
| Share HTML report | 3 min | SharePoint link | None |
| **Total** | **30 min** | **Integrated** | **Smooth** |

**Time saved**: 60 minutes (67%)
**Friction**: 85% reduction

---

## Success Metrics

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Weekly time investment | 270 min | 90 min | -67% |
| Articles reviewed | 20 | 45 | +125% |
| Images captured | 15 (40% missing) | 45 (100% preserved) | +200% |
| Team shares per week | 1 | 3 | +200% |
| Stakeholder satisfaction | 68% | 94% | +26% |

---

## Interface Benefits for Product Designers

### Why TUI Menu Works

**Visual Guidance**:
- No command memorization
- Clear options at each step
- Immediate feedback
- Error prevention (can't mis-type)

**Cognitive Load**:
- One decision at a time
- Visual progress indication
- Familiar selection patterns
- Undo-friendly (back navigation)

**Professional Output**:
- HTML reports look polished
- Images always preserved
- Consistent formatting
- Easy team sharing

---

## Journey Progression

### Week 1: Discovery
- Try interactive menu
- First successful fetch
- HTML output impresses
- Value immediately clear

### Week 2-4: Adoption
- 3x weekly routine established
- Learn bundle preferences
- Integrate with Figma workflow
- Share with team

### Month 2: Optimization
- Notice CLI pattern from menu logs
- Try occasional CLI for speed:
  ```bash
  ./capcat bundle tech --count 15 --html
  ```
- Still prefer menu for new tasks

### Month 3: Advocacy
- Share with 8 designers
- Team adopts for design reviews
- Become internal champion
- Contribute to bundle definitions

---

## Pain Points Solved

| Original Pain | Capcat Solution | Impact |
|---------------|-----------------|--------|
| Manual screenshots (60 min) | Automated image download | 100% time eliminated |
| Inconsistent formats | Professional HTML | 100% consistency |
| Lost inspiration links | Local preservation | 0% link decay |
| Fragmented tools | Integrated workflow | Single source of truth |
| Team sharing friction | HTML report links | Instant distribution |

---

## Feature Priorities for Designers

1. **Interactive menu**: Primary interface (Critical)
2. **HTML generation**: Presentation quality (Critical)
3. **Image preservation**: Visual content (Critical)
4. **Bundle presets**: Quick selection (High)
5. **Progress visualization**: Confidence building (High)
6. **Professional templates**: Stakeholder ready (Medium)

---

## User Quote

> "Interactive menu removed command-line anxiety entirely. HTML reports transformed design reviews from chaotic screenshots to systematic inspiration libraries. Team of 8 designers adopted within 2 weeks."
>
> — Maya Chen, Senior Product Designer

---

## Future Workflow Optimization

### Current: Manual Review (10 min)

Scan HTML → Select articles → Import images

### Potential: AI-Assisted Curation

```bash
# Future feature concept
./capcat bundle tech --count 15 --html \
    --ai-filter "design, typography, UI, visual" \
    --auto-highlight
```

**Result**: Pre-filtered, relevance-scored articles
**Time saved**: Additional 5 minutes
