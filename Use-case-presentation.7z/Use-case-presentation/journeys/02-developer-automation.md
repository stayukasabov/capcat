# User Journey: Developer Automation Workflow

## Journey Overview

**Persona**: Developer (Alex Rivera)
**Duration**: 5 minutes daily (automated), 30 minutes review
**Interface**: CLI commands (primary), zero TUI usage
**Time saved**: 89% vs manual process

## Emotional Arc

```
5 (Empowered)            ●
4 (Confident)        ●━━━●
3 (Satisfied)      ●
2 (Engaged)       ●
1 (Testing)      ●
                 │ │ │ │ │
                 CLI Test
                 Alias Setup
                 Cron Config
                 First Auto-run
                 Full Integration
```

## Journey Flow Diagram

```mermaid
graph TD
    A[Day 1: Discovery] --> B[Test CLI Commands]
    B --> C[./capcat list sources]
    C --> D[Review 17 Available Sources]

    D --> E[First Fetch Test]
    E --> F[./capcat bundle techpro --count 10]
    F --> G{Success?}

    G -->|Yes| H[Examine Output Structure]
    G -->|No| I[Check Logs]

    H --> J[Markdown Quality Check]
    J --> K[Comments Preserved]
    K --> L[Day 1 Success]

    I --> M[Fix Issues]
    M --> F

    L --> N[Day 2-7: Pattern Learning]
    N --> O[Try Different Bundles]
    N --> P[Test Single URL]
    N --> Q[Explore --media Flag]

    O --> R[Week 2: Optimization]
    P --> R
    Q --> R

    R --> S[Create Shell Aliases]
    S --> T[alias cap='./capcat']
    T --> U[alias captech='cap bundle techpro --count 25']

    U --> V[Week 3: Automation]
    V --> W[Write Cron Job]
    W --> X[0 7 * * * /path/to/capcat bundle techpro --count 25]

    X --> Y[Test Automation]
    Y --> Z{Works?}

    Z -->|Yes| AA[Week 4: Integration]
    Z -->|No| AB[Debug Paths/Permissions]

    AB --> AC[Fix crontab]
    AC --> Y

    AA --> AD[Obsidian Sync Script]
    AD --> AE[Automated Daily Workflow]
    AE --> AF[Zero Manual Intervention]

    style K fill:#d4f1d4
    style U fill:#e1f5e1
    style AE fill:#d4f1d4
    style AF fill:#d4f1d4
```

## Detailed Timeline

### Day 1: CLI Discovery (30 minutes)

**Morning 8:00 AM**: Initial testing

**Commands**:
```bash
# Install and first run
cd ~/capcat/Application
./capcat list sources

# Output review
17 sources available:
  hn (Hacker News)
  lb (Lobsters)
  iq (InfoQ)
  ...
```

**First Fetch**:
```bash
./capcat bundle techpro --count 10
```

**Output**:
```
Fetching techpro bundle (hn, lb, iq)...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 30/30 articles

✓ 30 articles saved to ../News/news_18-11-2025/
  Hacker-News_18-11-2025/ (10 articles)
  Lobsters_18-11-2025/ (10 articles)
  InfoQ_18-11-2025/ (10 articles)
```

**Examination**:
```bash
cd ../News/news_18-11-2025/Hacker-News_18-11-2025/
ls -la

01_Linux_Kernel_6.7_Released/
├── article.md         # Clean Markdown ✓
├── comments.md        # HN thread preserved ✓
├── images/
│   └── kernel-diagram.png
```

**Emotion**: Satisfied, CLI works as expected

---

### Day 2-7: Pattern Exploration (15 min/day)

**Testing Different Commands**:
```bash
# Day 2: Single source
./capcat fetch hn --count 15

# Day 3: Multiple sources
./capcat fetch hn,lb,googleai --count 20

# Day 4: Media download
./capcat fetch nature --count 10 --media

# Day 5: Single URL with comments
./capcat single https://news.ycombinator.com/item?id=38471822

# Day 6: Bundle exploration
./capcat bundle ai --count 15

# Day 7: List and test
./capcat list bundles
./capcat bundle science --count 10
```

**Learnings**:
- Bundle = predefined source groups
- `--media` = download videos/PDFs
- Comments always preserved for HN/Lobsters
- Markdown consistent and clean

**Emotion**: Engaged, exploring capabilities

---

### Week 2: Shell Optimization (30 minutes setup)

**Create Aliases** (.zshrc):
```bash
# Capcat aliases
alias cap='/Users/alex/capcat/Application/capcat'
alias captech='cap bundle techpro --count 25'
alias capai='cap bundle ai --count 20 --media'
alias capsci='cap bundle science --count 15'
alias caplist='cap list sources'
```

**Test Aliases**:
```bash
source ~/.zshrc
captech  # Works! 25 articles fetched
```

**Emotion**: Confident, workflow optimizing

---

### Week 3: Cron Automation (1 hour setup)

**Write Cron Job**:
```bash
crontab -e
```

**Crontab Entries**:
```bash
# Daily tech bundle at 7 AM
0 7 * * * /Users/alex/capcat/Application/capcat bundle techpro --count 25 >> /Users/alex/logs/capcat.log 2>&1

# Weekend deep dive at 9 AM
0 9 * * 6,7 /Users/alex/capcat/Application/capcat bundle science,ai --count 40 >> /Users/alex/logs/capcat-weekend.log 2>&1
```

**Test Automation**:
```bash
# Run manually first
/Users/alex/capcat/Application/capcat bundle techpro --count 25

# Check next morning (7:01 AM)
ls -la ../News/news_$(date +%d-%m-%Y)/
# ✓ Articles present!
```

**Debugging Common Issues**:
```bash
# Issue 1: PATH not found
# Fix: Use absolute paths in crontab

# Issue 2: Python venv not activated
# Fix: Wrapper script handles this

# Issue 3: No output
# Fix: Add logging redirection >> log.txt 2>&1
```

**Emotion**: Satisfied, automation working

---

### Week 4: Workflow Integration (2 hours)

**Obsidian Sync Script** (sync-to-obsidian.sh):
```bash
#!/bin/bash

NEWS_DIR="/Users/alex/News/news_$(date +%d-%m-%Y)"
VAULT_DIR="/Users/alex/Obsidian/Tech-Archive"
LOG_FILE="/Users/alex/logs/sync.log"

if [ -d "$NEWS_DIR" ]; then
    echo "[$(date)] Syncing $NEWS_DIR to Obsidian..." >> "$LOG_FILE"

    # Sync Markdown files only (exclude HTML)
    rsync -av \
        --include='*/' \
        --include='*.md' \
        --include='images/' \
        --include='*.png' \
        --include='*.jpg' \
        --exclude='*' \
        "$NEWS_DIR/" "$VAULT_DIR/Daily-$(date +%Y-%m-%d)/"

    echo "[$(date)] Sync complete" >> "$LOG_FILE"
else
    echo "[$(date)] No news directory found" >> "$LOG_FILE"
fi
```

**Update Crontab**:
```bash
# Daily tech bundle + sync
0 7 * * * /Users/alex/capcat/Application/capcat bundle techpro --count 25 && /Users/alex/scripts/sync-to-obsidian.sh
```

**Phone Sync (for commute reading)**:
```bash
# sync-to-phone.sh
rsync -av \
    --exclude='html/' \
    /Users/alex/News/news_$(date +%d-%m-%Y)/ \
    /Volumes/iPhone/Documents/Articles/
```

**Emotion**: Empowered, zero manual work

---

## Automation Architecture

```mermaid
graph LR
    A[7:00 AM Cron] --> B[Capcat Fetch]
    B --> C[../News/ Directory]

    C --> D[Obsidian Sync]
    C --> E[Phone Sync]

    D --> F[Obsidian Vault]
    E --> G[iPhone Storage]

    F --> H[Morning Review 7:30 AM]
    G --> I[Commute Reading 8:00 AM]

    H --> J[Tag Articles]
    J --> K[Link to Notes]

    I --> L[Offline Reading]
    L --> M[Evening Processing]
```

## Before/After Comparison

### Before Capcat (45 minutes daily)

| Task | Time | Tool | Friction |
|------|------|------|----------|
| Browse HN/Lobsters | 15 min | Browser | High |
| Save articles manually | 10 min | Pocket/Instapaper | Medium |
| Download PDFs | 5 min | Right-click save | High |
| Copy comments | 10 min | Manual copy-paste | Very high |
| Organize files | 5 min | Finder | Medium |
| **Total** | **45 min** | **Multiple** | **High** |

### With Capcat (5 minutes daily)

| Task | Time | Tool | Friction |
|------|------|------|----------|
| Automated fetch | 0 min | Cron (automated) | None |
| Automated sync | 0 min | Script (automated) | None |
| Morning review | 5 min | Obsidian | None |
| **Total** | **5 min** | **Integrated** | **Zero** |

**Time saved**: 40 minutes daily (89%)

---

## Success Metrics

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Daily time investment | 45 min | 5 min | -89% |
| Articles collected | 10 | 25-30 | +150% |
| Comments preserved | 0% | 95% | +95% |
| Offline reading time | 0 min | 90 min commute | +100% |
| Manual intervention | 100% | 0% | -100% |
| Knowledge base size | 300/month | 750/month | +150% |

---

## CLI Command Patterns

**Most Used (95% of usage)**:
```bash
# Daily automation
captech  # Alias: bundle techpro --count 25

# Weekend deep dive
cap bundle science,ai --count 40 --media

# Specific topic research
cap fetch googleai,openai,mitnews --count 15

# Single article (occasional)
cap single https://news.ycombinator.com/item?id=12345
```

**Rarely Used (5%)**:
```bash
# List commands (only when exploring)
cap list sources
cap list bundles

# Testing new sources
cap fetch newsource --count 5
```

**Never Used**:
```bash
# Interactive menu (too slow for power user)
./capcat catch  # ✗ Never
```

---

## Advanced Automation Examples

**Conditional Fetching**:
```bash
#!/bin/bash
# smart-fetch.sh - Only fetch if network is good

PING_TIME=$(ping -c 1 8.8.8.8 | grep 'time=' | awk -F'time=' '{print $2}' | awk '{print $1}')

if [ "${PING_TIME%.*}" -lt 50 ]; then
    /path/to/capcat bundle techpro --count 30
else
    echo "Network slow (${PING_TIME}ms), skipping"
fi
```

**Retry Logic**:
```bash
#!/bin/bash
# fetch-with-retry.sh

for i in {1..3}; do
    /path/to/capcat bundle techpro --count 25 && break
    echo "Attempt $i failed, retrying..."
    sleep 30
done || {
    echo "All retries failed" | mail -s "Capcat Failed" alex@example.com
}
```

**Multi-Stage Pipeline**:
```bash
#!/bin/bash
# complete-pipeline.sh

# Fetch
/path/to/capcat bundle techpro --count 25 || exit 1

# Sync to Obsidian
/path/to/sync-to-obsidian.sh || exit 1

# Generate summary
python3 /path/to/generate-summary.py

# Backup
tar -czf backup-$(date +%Y%m%d).tar.gz ../News/news_$(date +%d-%m-%Y)/
```

---

## Pain Points Solved

| Original Pain | Capcat Solution | Impact |
|---------------|-----------------|--------|
| 90-min commute wasted | Offline Markdown library | 100% productive time |
| Comments lost | Full HN/Lobsters threads | Complete technical context |
| 10 min per article | Bulk fetch in seconds | 95% time savings |
| Manual organization | Automated structure | 0 cognitive load |
| Tool fragmentation | Single CLI interface | Unified workflow |

---

## User Quote

> "CLI-first design respects power users. Set up cron automation in week 3, zero manual work since. 750 articles monthly in Obsidian, full HN comments preserved. 90-minute commute now productive deep reading."
>
> — Alex Rivera, Full-Stack Developer

---

## Journey Evolution

**Week 1**: CLI testing, exploration
**Week 2**: Alias creation, optimization
**Week 3**: Cron automation, first hands-off run
**Week 4**: Full integration (Obsidian, phone sync)
**Month 2**: Advanced pipelines, error handling
**Month 3**: Team sharing, documentation
**Month 4**: Community contribution, custom sources

**Final State**: 100% automated, 0% manual intervention
