# System Architecture Diagrams

## High-Level System Overview

```mermaid
graph TB
    subgraph User Entry Points
        A[CLI Commands]
        B[Interactive Menu]
        C[Automation/Cron]
    end

    subgraph Core Application
        D[CLI Parser]
        E[Interactive Menu System]
        F[Command Router]
    end

    subgraph Source System
        G[Source Registry]
        H[Source Factory]
        I[Config-Driven Sources]
        J[Custom Sources]
    end

    subgraph Processing Pipeline
        K[Article Fetcher]
        L[Content Processor]
        M[Media Processor]
        N[Comment Processor]
    end

    subgraph Output Generation
        O[Markdown Generator]
        P[HTML Generator]
        Q[File System Organizer]
    end

    subgraph Storage
        R[(Local File System)]
        S[../News/]
        T[../Capcats/]
    end

    A --> D
    B --> E
    C --> D
    D --> F
    E --> F

    F --> G
    G --> H
    H --> I
    H --> J

    I --> K
    J --> K

    K --> L
    L --> M
    L --> N

    M --> O
    N --> O
    O --> P
    P --> Q

    Q --> R
    R --> S
    R --> T

    style G fill:#e1f5e1
    style K fill:#e1f5e1
    style O fill:#e1f5e1
    style R fill:#ffe1e1
```

---

## User Interaction Flow

```mermaid
sequenceDiagram
    actor User
    participant CLI
    participant Menu
    participant Router
    participant Registry
    participant Fetcher
    participant Storage

    alt CLI Mode
        User->>CLI: ./capcat bundle tech --count 10
        CLI->>Router: Parse command + args
    else Interactive Mode
        User->>Menu: ./capcat catch
        Menu->>User: Display options
        User->>Menu: Select bundle + count
        Menu->>Router: Convert to command
    end

    Router->>Registry: Request sources for "tech"
    Registry-->>Router: [gizmodo, futurism, ieee]

    loop For each source
        Router->>Fetcher: Fetch 10 articles
        Fetcher->>Fetcher: Download + process
        Fetcher->>Storage: Save articles
        Storage-->>User: Progress update
    end

    Storage-->>User: ✓ 30 articles saved
```

---

## Source Discovery and Loading

```mermaid
graph TD
    A[Application Start] --> B[Source Registry Init]
    B --> C[Scan sources/active/]

    C --> D{Discover Sources}
    D --> E[config_driven/configs/*.yaml]
    D --> F[custom/*/source.py]

    E --> G[Parse YAML Configs]
    F --> H[Import Python Modules]

    G --> I[Create ConfigDrivenSource]
    H --> J[Instantiate Custom Source]

    I --> K[Validate Config Schema]
    J --> L[Validate BaseSource Interface]

    K --> M{Valid?}
    L --> M

    M -->|Yes| N[Register in SourceRegistry]
    M -->|No| O[Log Error + Skip]

    N --> P[Available for Use]
    O --> Q[Continue Discovery]

    P --> R[User Request]
    R --> S[Fetch from Registry]
    S --> T[Return Source Instance]

    style N fill:#d4f1d4
    style P fill:#d4f1d4
    style T fill:#d4f1d4
```

---

## Article Processing Pipeline

```mermaid
graph LR
    A[Source URL] --> B[HTTP Request]
    B --> C{Request Type}

    C -->|RSS| D[Parse RSS Feed]
    C -->|HTML| E[Scrape HTML]

    D --> F[Extract Article URLs]
    E --> F

    F --> G[For Each Article URL]
    G --> H[Fetch Article HTML]

    H --> I[Content Extraction]
    I --> J[Parse HTML Tree]
    J --> K[Apply Content Selectors]
    K --> L[Clean HTML]

    L --> M[Media Processing]
    M --> N{Media Type}

    N -->|Images| O[Always Download]
    N -->|Video/Audio/Docs| P{--media flag?}

    P -->|Yes| Q[Download Media]
    P -->|No| R[Skip Media]

    O --> S[Organize in images/]
    Q --> T[Organize in files/]

    S --> U[Convert to Markdown]
    T --> U
    R --> U

    U --> V[Generate article.md]
    V --> W{Comments Available?}
    W -->|Yes| X[Fetch Comments]
    W -->|No| Y[Skip Comments]

    X --> Z[Anonymize Usernames]
    Z --> AA[Generate comments.md]

    AA --> AB[Save to File System]
    Y --> AB

    AB --> AC[Output Complete]

    style O fill:#ffe1e1
    style U fill:#e1f5e1
    style AC fill:#d4f1d4
```

---

## Interactive Menu System

```mermaid
stateDiagram-v2
    [*] --> MainMenu

    MainMenu --> CatchFromBundle : Select option
    MainMenu --> CatchFromSources : Select option
    MainMenu --> CatchSingleSource : Select option
    MainMenu --> CatchSingleURL : Select option
    MainMenu --> ManageSources : Select option
    MainMenu --> [*] : Exit

    CatchFromBundle --> SelectBundle
    SelectBundle --> SetCount
    SetCount --> ConfirmHTML
    ConfirmHTML --> Execute

    CatchFromSources --> MultiSelect
    MultiSelect --> SetCount
    SetCount --> ConfirmHTML

    CatchSingleSource --> SelectSource
    SelectSource --> SetCount
    SetCount --> ConfirmHTML

    CatchSingleURL --> EnterURL
    EnterURL --> ConfirmHTML

    ManageSources --> SourceSubMenu
    SourceSubMenu --> AddSource : Add new
    SourceSubMenu --> RemoveSource : Remove
    SourceSubMenu --> ListSources : List
    SourceSubMenu --> MainMenu : Back

    AddSource --> EnterRSSURL
    EnterRSSURL --> IntrospectFeed
    IntrospectFeed --> GenerateConfig
    GenerateConfig --> TestSource
    TestSource --> MainMenu

    Execute --> Processing
    Processing --> ShowResults
    ShowResults --> MainMenu

    note right of Execute
        Converts menu selections
        to CLI command and
        executes
    end note
```

---

## Source Type Architecture

```mermaid
graph TD
    A[BaseSource Abstract Class] --> B[Config-Driven Source]
    A --> C[Custom Source Implementation]

    B --> D[YAML Config File]
    D --> E[source_id, display_name, category]
    D --> F[base_url, rss_url]
    D --> G[article_selectors, content_selectors]
    D --> H[template, timeout, rate_limit]

    C --> I[Python source.py Module]
    I --> J[Inherit from BaseSource]
    J --> K[Implement get_articles]
    J --> L[Implement fetch_article_content]
    J --> M[Optional: fetch_comments]

    B --> N[ConfigDrivenSource Class]
    N --> O[Generic RSS/HTML Parser]
    O --> P[Selector-Based Extraction]

    C --> Q[Source-Specific Logic]
    Q --> R[Custom API Calls]
    Q --> S[Complex Comment Threading]
    Q --> T[Special Authentication]

    P --> U[UnifiedSourceProcessor]
    R --> U
    S --> U
    T --> U

    U --> V[Article Output]

    style A fill:#ffe1e1
    style N fill:#e1f5e1
    style Q fill:#fff4e1
    style U fill:#e1e1ff
```

---

## Bundle Resolution Flow

```mermaid
graph TD
    A[User: ./capcat bundle tech] --> B[Load bundles.yml]
    B --> C[Parse YAML]

    C --> D{Bundle Exists?}
    D -->|No| E[Error: Unknown bundle]
    D -->|Yes| F[Extract Source List]

    F --> G[tech: gizmodo, futurism, ieee]
    G --> H[For Each Source in Bundle]

    H --> I[Query Source Registry]
    I --> J{Source Available?}

    J -->|No| K[Warning: Source not found]
    J -->|Yes| L[Get Source Instance]

    L --> M[Execute Fetch]
    M --> N[Combine Results]

    K --> O[Continue with Available Sources]
    O --> N

    N --> P[Generate Combined Output]
    P --> Q[Save to ../News/]

    E --> R[Display Available Bundles]
    R --> S[Exit]

    style F fill:#d4f1d4
    style M fill:#e1f5e1
    style Q fill:#d4f1d4
```

---

## Media Processing Pipeline

```mermaid
graph TB
    A[Article HTML] --> B[Scan for Media Elements]
    B --> C{Media Type Detection}

    C --> D[<img> Tags]
    C --> E[<video> Tags]
    C --> F[<audio> Tags]
    C --> G[<a href='*.pdf'> Links]

    D --> H[Image Processor]
    E --> I[Video Processor]
    F --> J[Audio Processor]
    G --> K[Document Processor]

    H --> L{Always Download}
    I --> M{--media Flag?}
    J --> M
    K --> M

    L -->|Yes| N[Download Image]
    M -->|Yes| O[Download Media]
    M -->|No| P[Skip Media]

    N --> Q[Process Image]
    Q --> R[Resize if Needed]
    R --> S[Optimize Quality]
    S --> T[Save to images/]

    O --> U[Save to files/]
    P --> V[Remove from Output]

    T --> W[Update Markdown Links]
    U --> W
    V --> W

    W --> X[Final article.md]

    style L fill:#ffe1e1
    style N fill:#d4f1d4
    style T fill:#d4f1d4
```

---

## Privacy and Anonymization Flow

```mermaid
graph TD
    A[Fetch Comments] --> B[Parse Comment HTML]
    B --> C[Extract Comment Data]

    C --> D[Detect Username Patterns]
    D --> E{Username Found?}

    E -->|Yes| F[Extract Profile URL]
    E -->|No| G[Keep Comment As-Is]

    F --> H[Replace Username with Anonymous]
    H --> I[Preserve Profile Link]

    I --> J[Output Format]
    J --> K[**Anonymous** → [profile link]]

    G --> L[Combine Comments]
    K --> L

    L --> M[Generate comments.md]
    M --> N{Verification Check}

    N --> O[Scan for Personal Data]
    O --> P{Personal Data Found?}

    P -->|Yes| Q[Error: Anonymization Failed]
    P -->|No| R[✓ Privacy Compliant]

    R --> S[Save comments.md]

    Q --> T[Log Issue + Block Save]

    style H fill:#ffe1e1
    style R fill:#d4f1d4
    style T fill:#ff0000,color:#fff
```

---

## Output Directory Structure

```mermaid
graph TD
    A[Command Execution] --> B{Mode}

    B -->|Batch| C[../News/news_DD-MM-YYYY/]
    B -->|Single| D[../Capcats/cc_DD-MM-YYYY-Title/]

    C --> E[Source_DD-MM-YYYY/]
    E --> F[01_Article_Title/]
    E --> G[02_Article_Title/]

    D --> H[Article Directory]

    F --> I[article.md]
    F --> J[comments.md optional]
    F --> K[images/]
    F --> L[files/]
    F --> M[html/ if --html flag]

    H --> I
    H --> J
    H --> K
    H --> L
    H --> M

    K --> N[content-image1.jpg]
    K --> O[content-image2.png]

    L --> P[document.pdf]
    L --> Q[video.mp4 if --media]

    M --> R[index.html]
    M --> S[assets/]

    S --> T[styles.css]
    S --> U[embedded-images/]

    style C fill:#e1f5e1
    style I fill:#d4f1d4
    style R fill:#fff4e1
```

---

## Error Handling Flow

```mermaid
graph TD
    A[Execute Command] --> B{Try Operation}
    B -->|Success| C[Continue]
    B -->|Error| D{Error Type}

    D -->|Network| E[Retry with Backoff]
    D -->|DNS| F[Log + Skip Source]
    D -->|Timeout| G[Retry Once]
    D -->|Parser| H[Fallback Extraction]
    D -->|Permission| I[Clear Error Message]

    E --> J{Retry Success?}
    J -->|Yes| C
    J -->|No| K[Mark as Failed]

    G --> L{Retry Success?}
    L -->|Yes| C
    L -->|No| K

    H --> M{Fallback Success?}
    M -->|Yes| N[Partial Content]
    M -->|No| K

    F --> K
    I --> O[Exit with Instructions]

    K --> P[Log to test-diagnose-*.md]
    P --> Q[Continue with Other Sources]

    C --> R[Process Next Item]
    N --> R
    Q --> R

    style C fill:#d4f1d4
    style K fill:#ffe1e1
    style O fill:#ff0000,color:#fff
```

---

## Summary

System architecture prioritizes:
- **Modularity**: Clear separation (sources, processing, output)
- **Extensibility**: Plugin-based source system
- **Reliability**: Comprehensive error handling
- **Privacy**: Built-in anonymization pipeline
- **Flexibility**: Multiple entry points and modes
- **Performance**: Parallel processing, shared sessions
