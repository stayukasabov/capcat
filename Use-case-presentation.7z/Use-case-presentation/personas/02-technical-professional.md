# Persona: Technical Professional

## Profile

**Name**: Marcus Johnson
**Age**: 29
**Role**: Senior Software Engineer
**Experience**: Very high technical, CLI power user
**Segment**: 30% of user base

## Goals

- Read tech articles offline (90-minute commute)
- Build personal knowledge base in Obsidian
- Stay current with tech trends
- Integrate with existing workflows

## Pain Points

| Problem | Impact | Severity |
|---------|--------|----------|
| No offline reading | Dead commute time | 9/10 |
| Poor article formats | Reading friction | 8/10 |
| Comments not preserved | Missing context | 7/10 |
| Manual process per article | Time waste | 6/10 |

## Daily Workflow

**Evening Sync** (15 minutes, 3-4x weekly)
1. Queue articles: `./capcat fetch hn,lb --count 20`
2. Watch parallel fetching → 19/20 success
3. Sync to phone storage
4. Commute reading → Offline access
5. Import tagged articles → Obsidian notes

**Before Capcat**: 45 minutes manual save
**With Capcat**: 15 minutes automated
**Time saved**: 67%

## Critical Features

- Comment preservation (HN, Lobsters)
- Markdown quality
- CLI automation
- Bulk operations
- Offline accessibility

## Usage Pattern

**Frequency**: 3-4x weekly
**Time**: Evening (7-9 PM)
**Articles per session**: 15-20
**Retention**: Very high (89% at 6 months)

## Automation Example

```bash
# Cron job: Daily tech bundle at 7 PM
0 19 * * * /path/to/capcat bundle techpro --count 25
```

## Success Metrics

- Offline reading: 100%
- Comment preservation: 95%
- Time savings: 67%
- Integration success: Obsidian, Notion

## Quote

> "90-minute commute transformed from dead time to deep learning. Comments preserved means full context."
