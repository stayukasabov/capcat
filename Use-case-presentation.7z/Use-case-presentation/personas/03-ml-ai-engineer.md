# Persona: ML/AI Engineer

## Profile

**Name**: Dr. Jordan Park
**Age**: 34
**Role**: ML Engineer, AI Research Team
**Experience**: Expert CLI + comfortable with TUI, hybrid usage
**Segment**: 20% of user base

## Goals

- Collect training data for LLM fine-tuning
- Build RAG knowledge bases from tech articles
- Curate datasets for embeddings and semantic search
- Automate data pipeline for AI research

## Pain Points

| Problem | Impact | Severity |
|---------|--------|----------|
| No structured data export for ML pipelines | Manual conversion | 10/10 |
| Inconsistent Markdown for embeddings | Data quality issues | 9/10 |
| No bulk metadata extraction | Pipeline bottleneck | 8/10 |
| Manual dataset curation (10+ hrs weekly) | Time waste | 9/10 |

## Daily Workflow

**Data Collection Pipeline** (Hybrid: TUI + CLI)

**Interactive Exploration** (15 minutes, weekly):
```bash
./capcat catch
→ Manage Sources
→ Add Source → Test new RSS feeds
→ Validate content quality for training data
```

**Automated Bulk Collection** (5 minutes setup, runs daily):
```bash
# Cron: Daily at 2 AM for overnight processing
0 2 * * * /path/to/collect-training-data.sh
```

**Before Capcat**: 10 hours weekly manual curation
**With Capcat**: 1 hour weekly supervision
**Time saved**: 90%

## Critical Features

- **Markdown consistency**: Clean format for embeddings
- **Bulk operations**: 100+ articles for dataset creation
- **Metadata preservation**: Titles, dates, sources, URLs
- **Comment data**: Additional training corpus
- **Scriptable interface**: Pipeline integration
- **TUI for exploration**: Quick source testing

## Interface Preference

**Hybrid Approach**:

**TUI for exploration**:
```bash
# Weekly: Test new sources for data quality
./capcat catch
→ Add Source (test RSS feed)
→ Validate output quality
→ Add to production pipeline
```

**CLI for production**:
```bash
# Daily: Automated data collection
./capcat fetch hn,lb,googleai,openai,mitnews --count 100

# Weekly: Bulk dataset creation
./capcat bundle ai,techpro,science --count 500 --media
```

## Usage Pattern

**Frequency**: Daily automated + weekly curation
**Time**: 2:00 AM (automated), Friday 2-3 PM (curation)
**Articles per week**: 700-1000
**Retention**: Extremely high (97% at 12+ months)

## ML Pipeline Integration

**Training Data Collection**:
```bash
#!/bin/bash
# collect-training-data.sh

# Fetch diverse sources for LLM training
./capcat bundle ai,techpro,science --count 500

# Extract metadata for dataset
python3 extract-metadata.py ../News/news_$(date +%d-%m-%Y)/

# Convert to JSONL for training
python3 convert-to-jsonl.py \
    --input ../News/news_$(date +%d-%m-%Y)/ \
    --output datasets/training_$(date +%Y%m%d).jsonl

# Generate embeddings
python3 generate-embeddings.py \
    --model text-embedding-ada-002 \
    --input datasets/training_$(date +%Y%m%d).jsonl
```

**RAG Knowledge Base**:
```python
# rag-pipeline.py

import os
from pathlib import Path
import chromadb

def process_capcat_articles(news_dir):
    """Process Capcat Markdown into vector DB"""

    client = chromadb.Client()
    collection = client.create_collection("tech_articles")

    for article_dir in Path(news_dir).rglob("*/"):
        article_md = article_dir / "article.md"
        comments_md = article_dir / "comments.md"

        if article_md.exists():
            # Extract article content
            with open(article_md) as f:
                content = f.read()

            # Add to vector DB
            collection.add(
                documents=[content],
                metadatas=[{
                    "source": article_dir.name,
                    "path": str(article_md),
                    "has_comments": comments_md.exists()
                }],
                ids=[str(article_dir)]
            )

    return collection
```

## Success Metrics

- Time savings: 90% (10 hrs → 1 hr weekly)
- Dataset size: 3,000+ articles monthly
- Data quality: 98% usable for embeddings
- RAG retrieval accuracy: 92%
- Pipeline automation: 95% hands-off

## User Quote

> "TUI for source exploration, CLI for production pipelines. Bulk Markdown collection fuels LLM fine-tuning. RAG knowledge base built from 3,000+ curated articles. 90% time savings in dataset curation."

## Journey Progression

**Week 1**: Test CLI and TUI for data collection
**Week 2**: Build metadata extraction pipeline
**Week 3**: Setup automated cron jobs
**Month 2**: RAG integration with ChromaDB
**Month 3**: LLM fine-tuning with curated data
**Month 4**: Production deployment, team scaling

## Hybrid Usage Patterns

**TUI Usage (10%)**:
- Source exploration and testing
- Quality validation before production
- Quick single-URL captures for experiments
- Visual confirmation of output structure

**CLI Usage (90%)**:
- Bulk data collection (daily automation)
- Integration with ML pipelines
- Dataset generation
- Embedding creation

## Data Processing Pipeline

```mermaid
graph LR
    A[Capcat Fetch] --> B[Markdown Files]
    B --> C[Metadata Extraction]
    C --> D[JSONL Conversion]
    D --> E{Purpose}

    E -->|Training| F[LLM Fine-tuning]
    E -->|RAG| G[Vector DB]
    E -->|Analysis| H[Sentiment/Topic Modeling]

    F --> I[Custom AI Model]
    G --> J[Semantic Search]
    H --> K[Insights Dashboard]
```

## Pain Points Solved

| Original Pain | Capcat Solution | Impact |
|---------------|-----------------|--------|
| Manual curation (10 hrs) | Automated bulk fetch | 90% time savings |
| Inconsistent formats | Standardized Markdown | 98% data quality |
| No metadata extraction | Preserved in frontmatter | Pipeline ready |
| Small training datasets | 1,000+ articles weekly | 10x dataset size |

## Feature Priorities

1. **Markdown consistency**: Embedding quality (Critical)
2. **Bulk operations**: 100+ article fetches (Critical)
3. **Metadata preservation**: Training data labels (Critical)
4. **Comment extraction**: Additional corpus (High)
5. **Scriptable CLI**: Pipeline integration (High)
6. **TUI for testing**: Source validation (Medium)

## Technical Comfort Zone

**Expert Level**:
- CLI scripting and automation
- Python data pipelines
- ML/AI frameworks (PyTorch, TensorFlow)
- Vector databases (ChromaDB, Pinecone, Weaviate)
- LLM APIs (OpenAI, Anthropic, local models)
- Cron, systemd, workflow orchestration

**Advanced Usage**:
- Metadata schema design
- Embedding generation
- RAG architecture
- Fine-tuning workflows
- Data quality validation

**Hybrid Proficiency**:
- TUI for exploration (quick testing)
- CLI for automation (production)
- Mix based on task context

## ML/AI Use Cases

### Use Case 1: LLM Fine-Tuning Dataset

**Goal**: Create domain-specific training data

**Process**:
```bash
# Collect 10,000 tech articles
./capcat bundle ai,techpro,science --count 10000

# Convert to training format
python convert-to-training.py \
    --input ../News/ \
    --output training_data.jsonl \
    --format openai

# Fine-tune model
openai api fine_tunes.create \
    -t training_data.jsonl \
    -m gpt-3.5-turbo
```

**Result**: Domain-specific AI model for tech Q&A

---

### Use Case 2: RAG Knowledge Base

**Goal**: Semantic search over tech articles

**Process**:
```bash
# Daily collection
./capcat bundle ai --count 50

# Generate embeddings
python embed-articles.py \
    --model sentence-transformers/all-MiniLM-L6-v2 \
    --input ../News/news_$(date +%d-%m-%Y)/

# Query via RAG
python query-rag.py \
    --query "What are recent LLM breakthroughs?" \
    --top_k 5
```

**Result**: Accurate retrieval from 3,000+ article knowledge base

---

### Use Case 3: Sentiment/Topic Analysis

**Goal**: Track AI/ML trends over time

**Process**:
```python
# analyze-trends.py

from transformers import pipeline
import glob

sentiment_model = pipeline("sentiment-analysis")
topic_model = pipeline("zero-shot-classification")

articles = glob.glob("../News/**/article.md", recursive=True)

for article in articles:
    with open(article) as f:
        content = f.read()

    # Sentiment analysis
    sentiment = sentiment_model(content[:512])[0]

    # Topic classification
    topics = topic_model(
        content[:512],
        candidate_labels=[
            "LLM", "Computer Vision",
            "Robotics", "Ethics"
        ]
    )

    # Store for trend analysis
    store_analysis(article, sentiment, topics)
```

**Result**: Trend dashboard tracking AI topic evolution

---

### Use Case 4: Comment Analysis Corpus

**Goal**: Build conversational dataset from HN/Lobsters

**Process**:
```bash
# Fetch with comments
./capcat fetch hn,lb,lesswrong --count 200

# Extract comment threads
python extract-comments.py \
    --input ../News/ \
    --output comments_corpus.jsonl \
    --min_thread_depth 3

# Fine-tune conversational model
python finetune-conversational.py \
    --corpus comments_corpus.jsonl
```

**Result**: Conversational AI trained on technical discussions

---

## Automation Examples

**Weekly Dataset Creation**:
```bash
# Crontab: Every Sunday at 1 AM
0 1 * * 0 /path/to/weekly-dataset.sh
```

**weekly-dataset.sh**:
```bash
#!/bin/bash

# Collect week's articles
./capcat bundle ai,techpro,science --count 700

# Process into training format
python process-weekly-data.py \
    --week $(date +%V) \
    --year $(date +%Y)

# Update embeddings
python update-embeddings.py \
    --incremental

# Backup dataset
tar -czf datasets/week_$(date +%Y%V).tar.gz datasets/
```

## Integration Tools

- **Vector DBs**: ChromaDB, Pinecone, Weaviate, Qdrant
- **LLM APIs**: OpenAI, Anthropic, Cohere, local LLaMA
- **Embedding Models**: OpenAI ada-002, sentence-transformers
- **ML Frameworks**: PyTorch, TensorFlow, Hugging Face
- **Orchestration**: Airflow, Prefect, Luigi
- **Storage**: S3, MinIO, local file system
