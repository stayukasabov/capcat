# Persona: Developer

## Profile

**Name**: Alex Rivera
**Age**: 28
**Role**: Full-Stack Developer, Tech Lead
**Experience**: High CLI proficiency, power user
**Segment**: 45% of user base

## Goals

- Stay current with tech trends and frameworks
- Build personal knowledge base with comments
- Automate daily tech news aggregation
- Integrate archiving into development workflow

## Pain Points

| Problem | Impact | Severity |
|---------|--------|----------|
| No offline reading (90-min commute) | Dead time | 9/10 |
| Comments not preserved (HN, Lobsters) | Missing context | 8/10 |
| Manual article saving (10 min each) | Time waste | 7/10 |
| Markdown inconsistency across tools | Integration friction | 6/10 |

## Daily Workflow

**Morning Tech Digest** (5 minutes)
```bash
# Automated via cron at 7:00 AM
./capcat fetch hn,lb,iq --count 30 --media
```

**Evening Review** (30 minutes)
```bash
# Sync to phone for commute
rsync -av ../News/news_$(date +%d-%m-%Y)/ ~/phone-sync/
```

**Before Capcat**: 45 minutes manual save + organize
**With Capcat**: 5 minutes automated + 0 manual
**Time saved**: 89%

## Critical Features

- **CLI-first interface**: Direct command execution
- **Comment preservation**: Full HN/Lobsters threads
- **Markdown output**: Obsidian/Notion integration
- **Bulk operations**: 30+ articles in one command
- **Scriptable**: Automation via cron/shell scripts

## Interface Preference

**Primary**: CLI commands
```bash
# Daily tech bundle
./capcat bundle techpro --count 25

# Specific sources with media
./capcat fetch hn,lb --count 20 --media

# Single article with comments
./capcat single https://news.ycombinator.com/item?id=12345

# Custom source list
./capcat fetch nature,ieee,googleai --count 15
```

**Never**: Interactive menu (too slow for power users)

## Usage Pattern

**Frequency**: Daily (automated)
**Time**: 7:00 AM (cron), 6:00 PM (review)
**Articles per session**: 25-30
**Retention**: Very high (94% at 12 months)

## Automation Setup

**Crontab**:
```bash
# Daily tech bundle at 7 AM
0 7 * * * /path/to/capcat bundle techpro --count 25 --media

# Weekend deep dive at 9 AM
0 9 * * 6,7 /path/to/capcat bundle science,ai --count 40

# Log rotation
0 0 * * 0 /path/to/cleanup-old-archives.sh
```

**Shell Aliases**:
```bash
alias cap='/path/to/capcat'
alias captech='cap bundle techpro --count 25'
alias capai='cap bundle ai --count 20 --media'
alias capsci='cap bundle science --count 15'
```

**Integration Script**:
```bash
#!/bin/bash
# sync-to-obsidian.sh

NEWS_DIR="../News/news_$(date +%d-%m-%Y)"
VAULT_DIR="$HOME/Obsidian/Tech-Archive"

if [ -d "$NEWS_DIR" ]; then
    rsync -av --exclude='html/' "$NEWS_DIR/" "$VAULT_DIR/"
    echo "Synced $(date)" >> "$VAULT_DIR/sync.log"
fi
```

## Success Metrics

- Time savings: 89% (45 min → 5 min)
- Automation coverage: 100% daily workflow
- Comment preservation: 95% success rate
- Offline reading: 90 minutes daily
- Knowledge base growth: 600+ articles/month

## User Quote

> "CLI-first design respects power users. Comments preserved means full context. Automated daily digest syncs to Obsidian before I wake. Zero manual intervention."

## Journey Progression

**Day 1**: Test CLI commands
**Day 2-7**: Explore sources and bundles
**Week 2**: Create shell aliases
**Week 3**: Setup cron automation
**Month 2**: Integration scripts (Obsidian, Notion)
**Month 3**: Custom bundle creation
**Month 4**: Team sharing, documentation

## CLI Command Patterns

**Most Used**:
```bash
./capcat bundle techpro --count 25        # 70% of usage
./capcat fetch hn,lb --count 20           # 15%
./capcat single <URL>                     # 10%
./capcat list sources                     # 5%
```

**Advanced Usage**:
```bash
# Parallel fetch with different configs
./capcat fetch hn --count 30 & \
./capcat fetch nature --count 20 --media & \
wait

# Conditional archiving
if curl -s https://status.api.com | grep -q "operational"; then
    ./capcat bundle tech --count 30
fi

# Integration with other tools
./capcat bundle ai --count 20 | \
    tee -a ai-articles-$(date +%Y%m%d).log
```

## Pain Points Solved

| Original Pain | Capcat Solution | Impact |
|---------------|-----------------|--------|
| 90-min commute wasted | Offline Markdown library | 100% time productive |
| Comments missing | Full thread preservation | Complete context |
| 10 min per article | Bulk fetch in seconds | 95% faster |
| Manual organization | Automated directory structure | 0 manual work |

## Feature Priorities

1. **CLI interface**: Direct commands (Critical)
2. **Comment preservation**: HN, Lobsters, LessWrong (Critical)
3. **Markdown quality**: Clean, standard format (Critical)
4. **Bulk operations**: 30+ concurrent (High)
5. **Scriptability**: Exit codes, logging (High)
6. **Media filtering**: --media flag (Medium)

## Technical Comfort Zone

**Expert Level**:
- CLI command construction
- Shell scripting (bash, zsh)
- Cron automation
- Process management
- Git workflows
- Environment variables
- SSH, rsync, curl

**Advanced Usage**:
- Custom bundle creation (YAML editing)
- Source introspection
- Log analysis
- Performance optimization
- Integration scripting

**Avoids**:
- Interactive menus (too slow)
- GUI tools (prefer terminal)
- Manual processes (automate everything)

## Workflow Integration

**Development Stack**:
- **Obsidian**: Markdown knowledge base
- **Notion**: Team documentation
- **Git**: Version control for configs
- **Zsh**: Shell with aliases and functions
- **Tmux**: Terminal multiplexing
- **Neovim**: Text editing

**Daily Routine**:
```bash
# Morning (automated)
7:00 AM - Cron fetches 25 articles
7:05 AM - Sync to Obsidian vault
7:10 AM - Sync to phone for commute

# Evening (manual review)
6:00 PM - Review Obsidian inbox
6:15 PM - Tag relevant articles
6:30 PM - Update personal notes
```

## Advanced Patterns

**Conditional Fetching**:
```bash
# Only fetch if network is fast
if ping -c 1 8.8.8.8 -W 1 | grep -q "time="; then
    ./capcat bundle techpro --count 30
else
    echo "Network slow, skipping"
fi
```

**Error Handling**:
```bash
# Retry logic with notification
for i in {1..3}; do
    ./capcat bundle tech --count 20 && break
    echo "Retry $i of 3..."
    sleep 10
done || notify-send "Capcat fetch failed"
```

**Multi-Stage Pipeline**:
```bash
# Fetch → Process → Backup
./capcat bundle ai --count 20 && \
    ./process-articles.sh && \
    tar -czf backup-$(date +%Y%m%d).tar.gz ../News/
```
