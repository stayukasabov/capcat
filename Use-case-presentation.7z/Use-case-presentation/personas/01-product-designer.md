# Persona: Product Designer

## Profile

**Name**: Maya Chen
**Age**: 32
**Role**: Senior Product Designer, Design Systems
**Experience**: Moderate terminal comfort, prefers visual tools
**Segment**: 35% of user base

## Goals

- Curate design inspiration from tech publications
- Build visual research library for design reviews
- Share professional reports with stakeholders
- Maintain organized archive for pattern references

## Pain Points

| Problem | Impact | Severity |
|---------|--------|----------|
| Manual screenshot collection (3 hrs weekly) | Time waste | 9/10 |
| Inconsistent formatting for presentations | Professional credibility | 8/10 |
| Lost inspiration articles (links break) | Design reference loss | 8/10 |
| No offline access to research | Blocked creativity | 7/10 |

## Daily Workflow

**Research Collection Routine** (30 minutes, 3x weekly)
1. Launch: `./capcat catch`
2. Select: Catch from Bundle → tech
3. Set count: 15 articles
4. Enable HTML: Yes
5. Review visual content in HTML report
6. Import relevant articles to Figma/Miro

**Before Capcat**: 90 minutes manual save
**With Capcat**: 30 minutes automated
**Time saved**: 67%

## Critical Features

- **Interactive TUI menu**: No command memorization
- **HTML generation**: Professional presentation format
- **Image preservation**: Visual content always downloaded
- **Organized output**: Date-based directory structure
- **Visual progress**: Progress bars during fetch

## Interface Preference

**Primary**: Interactive menu (`./capcat catch`)
- Visual source selection
- Guided workflow
- No syntax errors
- Immediate feedback

**Occasional**: CLI for repetition
```bash
# After learning pattern from menu
./capcat bundle tech --count 15 --html
```

## Usage Pattern

**Frequency**: 3x weekly (Mon/Wed/Fri mornings)
**Time**: 9:00-9:30 AM
**Articles per session**: 12-15
**Retention**: High (86% at 6 months)

## Workflow Integration

**Design Tools**:
- Figma: Import images for mood boards
- Miro: Reference boards with article screenshots
- Notion: Design documentation with embedded articles
- Slack: Share HTML reports with team

**Automation Example**:
```bash
# Cron: Monday/Wednesday/Friday at 8:45 AM
45 8 * * 1,3,5 /path/to/capcat bundle tech --count 15 --html
```

Articles ready before morning review.

## Success Metrics

- Time savings: 67% (60 min → 20 min per session)
- HTML report quality: 95% stakeholder approval
- Image preservation: 100% (vs 40% manual)
- Design review efficiency: +35%
- Team adoption: 8 designers

## User Quote

> "Interactive menu removes command-line anxiety. HTML reports impress stakeholders. Visual inspiration archive transformed design reviews from chaotic to systematic."

## Journey Progression

**Week 1**: Interactive menu exclusively
**Week 2-4**: Learn patterns from menu
**Month 2**: Occasional CLI for repeated tasks
**Month 3**: Cron automation for routine fetches
**Month 4**: Team sharing and advocacy

## Menu Usage Patterns

**Most Used Flows**:
1. Catch from Bundle (85%)
2. Catch Single URL (10%)
3. Manage Sources (5%)

**Rarely Used**:
- Catch from Multiple Sources (complex selection)
- Direct CLI (only after pattern learned)

## Pain Points Solved

| Original Pain | Capcat Solution | Impact |
|---------------|-----------------|--------|
| 3 hrs weekly screenshots | 30 min automated | 83% time savings |
| Inconsistent formats | Professional HTML | 100% consistency |
| Lost inspiration links | Local preservation | 0% link decay |
| Manual image downloads | Always downloaded | 100% image capture |

## Feature Priorities

1. **Interactive menu**: Primary interface (Critical)
2. **HTML generation**: Presentation output (Critical)
3. **Image download**: Visual content (Critical)
4. **Bundle presets**: Quick selection (High)
5. **Progress feedback**: Visual confirmation (Medium)

## Technical Comfort Zone

**Comfortable**:
- Interactive TUI menus
- Basic terminal commands
- File navigation
- Copy/paste operations

**Learning Edge**:
- CLI flags and arguments
- Shell aliases
- Cron job basics
- Environment variables

**Avoid**:
- Complex scripting
- Advanced automation
- Custom source development
- YAML configuration editing
