# Persona: Information Researcher

## Profile

**Name**: Dr. Sarah Chen
**Age**: 35
**Role**: PhD Candidate, Computational Biology
**Experience**: High technical, moderate CLI comfort
**Segment**: 40% of user base

## Goals

- Preserve articles with citation integrity
- Maintain persistent references for dissertation
- Prevent broken links
- Organize research library locally

## Pain Points

| Problem | Impact | Severity |
|---------|--------|----------|
| Citations break (40% within 6 months) | Cannot verify sources | 10/10 |
| Manual organization (2 hours daily) | Time waste | 9/10 |
| Paywalls appear retroactively | Lost access | 10/10 |
| Cannot verify content sources | Research credibility | 7/10 |

## Daily Workflow

**Morning Research Routine** (45 minutes)
1. Scan RSS feeds → Identify 5-7 topics
2. Archive bulk: `./capcat fetch nature,scientificamerican --count 50`
3. Review saved Markdown → Tag 12 relevant articles
4. Import to Obsidian → Link existing notes
5. Write with citations → Zero broken links

**Before Capcat**: 120 minutes
**With Capcat**: 45 minutes
**Time saved**: 63%

## Critical Features

- Citation metadata preservation
- Bulk source fetching
- Article deduplication
- Search within archives
- Content preservation guarantees

## Usage Pattern

**Frequency**: Daily
**Time**: 7:00-7:45 AM
**Articles per session**: 40-50
**Retention**: High (92% at 6 months)

## Success Metrics

- Citation integrity: 100%
- Link persistence: 100%
- Time savings: 63%
- Article quality: 98% success rate

## Quote

> "Citation decay destroyed 30% of my dissertation references. Local archiving ensures my research stays verifiable."
